package org.sino.pedia.subject.config.provider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

//@EnableNacos(globalProperties = @NacosProperties(serverAddr = "${spring.cloud.nacos.config.server-addr:127.0.0.1:8848}"))
@EnableDiscoveryClient
@SpringBootApplication
public class SubjectConfigProvider {
	public static void main(String[] args) {
		SpringApplication.run(SubjectConfigProvider.class, args);
	}
}
