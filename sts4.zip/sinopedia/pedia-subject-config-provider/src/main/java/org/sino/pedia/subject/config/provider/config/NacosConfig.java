package org.sino.pedia.subject.config.provider.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.alibaba.nacos.api.config.annotation.NacosConfigurationProperties;

@Configuration
@RefreshScope
@NacosConfigurationProperties(dataId = "ums", groupId = "DEFAULT_GROUP", autoRefreshed = true)
public class NacosConfig {
	@LoadBalanced
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
